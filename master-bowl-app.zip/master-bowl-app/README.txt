PET BOWL MASTER — offline copy
==============================

Pet Bowl Master.html
    Double-click it. That is the whole app — no install, no server.
    Set the sizes, type the pet's name, press "Download STL set" and you
    get a zip with body.stl, tray.stl and print-notes.txt.

    You can also drop an SVG logo onto the page — it is embossed into the
    same top rim as the name. Drag either the name or the logo on the 3D
    preview to move it anywhere round the ring.

    Each can be laid out two ways:
        Curved  wraps round the rim. Natural for text.
        Flat    lies straight, undistorted. What you want for a logo —
                curved bends a square into a banana.
    The name defaults to Curved, the logo to Flat.

    Works offline. The one thing that needs internet is the lettering:
    the Kanit and IBM Plex fonts come from Google Fonts. Offline, Thai
    still renders using a Windows system font, so names work either
    way — they just look slightly different from the online version.

    Tested in Chrome and Edge. Needs WebGL2 for the 3D preview; if the
    preview is blank the download still works.

src\
    The three source files the page is built from, plus build.py.
    shell.html  markup and all the CSS
    geo.js      the parametric geometry engine — this is the real model.
                It also runs under node, which is how it was verified:
                    node -e "const {PBM}=require('./geo.js'); ..."
    app.js      UI, WebGL viewer, name and SVG logo engravers,
                STL and zip writers

    Edit any of them, then:  python src\build.py
    That regenerates "Pet Bowl Master.html".

ABOUT body.stl
    It contains the holder as one watertight shell, plus one small closed
    solid per letter stroke — and, if you added one, per piece of the logo
    — sitting in the rim. All of them are watertight with consistent
    winding; the slicer unions them when it loads the file. So if it
    reports "134 objects" or offers to repair the mesh, that is the
    lettering and the logo, and you can decline. Where two of those solids
    touch, four faces meet along one edge; that is normal for a file of
    separate solids and is not a hole. tray.stl is always a single shell.

ABOUT FLAT vs CURVED
    Both go through one pipeline: rasterise, decompose into rectangles,
    extrude each as a closed box. Only the last step differs — geo.js
    nameMesh() bends the rect field round the ring, flatMesh() lays it on a
    plane. Both use the same axis convention, so switching modes never
    mirrors or flips the artwork.

    Flat has less room than curved, because the top face is an annulus: a
    straight rectangle runs off it long before an arc band does, and the
    face is a CIRCLE on the inside (the bowl seat) but a SQUIRCLE outside.
    So the flat area varies a lot with position — for the Puppy preset,
    roughly 90 x 9 mm along a flat side but 50 x 17 mm at a corner. Flat
    artwork is scaled down automatically to fit wherever you drag it, and
    the app says so. If it shrinks too much, drag it to a corner.

ABOUT THE SVG LOGO
    It is rasterised, then decomposed into rectangles and swept onto the
    ring as closed boxes — the same path the lettering takes, so it comes
    out watertight by construction too.

    Use filled shapes. A stroke-only drawing rasterises as hairlines; the
    app measures how much of the artwork is finer than 0.8 mm (by eroding
    and dilating it back) and warns you, because a 0.4 mm nozzle drops
    anything thinner. Expand strokes to outlines before exporting.

    An SVG that pulls in an external bitmap will not work — the browser
    blocks or taints it. Embed the artwork as paths.

WHAT THE MODEL GUARANTEES
    Every part is one closed cross-section swept around a superellipse,
    so both STLs come out watertight with consistent winding — no CSG,
    no repair step. Verified across bowl 110-180 mm, round through boxy,
    tray 10-34 mm, handles on and off.

    The ant gap is the design driver, not a by-product: the holder's
    underside hugs a sphere of that radius centred on the tray's top
    outer edge, so the visible gap between the two parts IS the barrier.

PRINTING
    Part A   INVERTED — top face on the bed. No supports.
    Part B   as exported, floor down. 12 bottom layers so the trough
             holds water. No supports.
    PETG or ASA for Part B; it sits in standing water permanently.

    Full settings are written into print-notes.txt with every download.
